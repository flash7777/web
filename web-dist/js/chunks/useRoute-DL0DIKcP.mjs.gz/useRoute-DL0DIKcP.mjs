import{cl as e}from"./NoContentMessage.vue_vue_type_style_index_0_scoped_a1dde729_lang-BVyeepj5.mjs";const t=()=>e().currentRoute;export{t as u};
